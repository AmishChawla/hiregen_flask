# AI Recruitment Masterclass — course dataset

500 synthetic resumes for a single role family (data engineering), a job brief,
and a shortlist of 20 produced by a human reviewer reading everything by hand.

**Everything here is fabricated.** No real people, employers, email addresses or
phone numbers. Email domains use the reserved `.test` TLD. Free to reuse,
including in your own training material.

## Contents

| Path | What it is |
|---|---|
| `resumes/` | 495 readable resumes — PDF and DOCX |
| `resumes/scanned/` | 3 scanned PDFs with no text layer (your OCR worst case) |
| `resumes/unreadable/` | 2 password-protected PDFs that will fail ingestion |
| `job-brief.md` | Intake notes for the role — deliberately incomplete |
| `human-shortlist.csv` | 20 candidates picked by a human, with notes |
| `manifest.csv` | Ground truth: every candidate's career shape and format |

## What is deliberately messy

- **Five date conventions** across the set: `Mar 2021`, `03/2021`, `2021-03`,
  `Spring 2021`, `Mar'21`.
- **40 two-column layouts** with a sidebar — the most common cause of
  reading-order failure.
- **3 scans**, greyscale, slightly rotated, reduced contrast.
- **2 password-protected files** so the count of parsed candidates does not
  match the count of files. Module 4, Lesson 4, Step 1 is about noticing this.
- **Concurrent contract engagements** with overlapping dates, which often parse
  as duplicate or impossible tenure.
- **Career gaps**, **career changers**, and candidates whose only relevant
  evidence sits inside a project description rather than an employment entry.
- **Varied section headings**, including some that are not called "Experience".
- **Names from many naming traditions**, because entity extraction quality is
  not evenly distributed and that is worth seeing for yourself.

## Using `manifest.csv`

It is ground truth — the answer key. Do the labs first without it, then use it
to check what your screening actually missed. In particular: filter to
`career_shape = changer` or `project_only` and see where those candidates
landed in your ranking.

## A note on the human shortlist

It was produced by a person reading all 500, and it contains that person's
blind spots as well as their judgement — career changers and scanned resumes
fare worse in it than they should. That is the point. Module 4, Lab 3 asks you
to compare against it, not to match it.
