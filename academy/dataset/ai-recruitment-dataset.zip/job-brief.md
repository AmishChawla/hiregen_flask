# Job brief — Senior Data Engineer

*Notes from the intake meeting. Deliberately incomplete: this is what a real
intake produces, not a finished specification.*

**Team:** Data Platform, currently 4 engineers, reporting to the Head of Data.
**Location:** Hybrid, two days a week in office. Some flexibility.
**Opened:** Because the previous senior engineer left in June and nobody has
owned the ingestion layer since.

## What the hiring manager said

"We need someone who can own the pipelines end to end. Right now everything
routes through me and I'm the bottleneck. In six months I want them running
the ingestion layer without checking in, and I want the nightly reconciliation
job to stop failing."

"The last person we hired for this didn't work out. Great on paper — all the
right tools — but they'd never had to fix something at 2am and they wanted
every decision signed off. I need someone who has carried a pager."

"They'll work with finance a lot. The month-end reporting depends on us and
finance are not technical, so they need to be able to explain a delay without
being defensive about it."

"Orchestration and warehouse experience has to arrive intact — we don't have
time to teach it. Our specific stack they can pick up; I don't care if they've
used our exact tools."

## Discussed, not resolved

- Compensation range: "market rate, we'll be competitive" — no number given.
- Seniority: described as senior, but also "could be a strong mid who's ready".
- Who else interviews: the Head of Data, and "probably someone from finance".
- Timeline: "as soon as possible", no target date agreed.
- Whether the role is backfill or additional headcount: unclear.

## Notes

The manager mentioned twice that the last hire needed close direction. That
did not appear anywhere in the original job description.
